#ifndef TMENSAGEM_H
#define TMENSAGEM_H

//Imprime alguma mesagem com o \n
void Msg(char * msg);

//Imprime alguma mesagem com o \n e ERRO: na ferente
void MsgErro(char * msg);

#endif /* TMENSAGEM_H */
