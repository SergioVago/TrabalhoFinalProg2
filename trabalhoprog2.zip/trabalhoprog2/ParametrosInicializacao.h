#ifndef PARAMETROSINICIALIZACAO_H
#define PARAMETROSINICIALIZACAO_H

//Funcao que testa o caminho passado pela linha de comando
int TestaArq(int argc,char** argv);

#endif /* PARAMETROSINICIALIZACAO_H */
